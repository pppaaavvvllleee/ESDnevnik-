﻿namespace ESDnevnik2023A
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.BTN_first = new System.Windows.Forms.Button();
            this.BTN_prev = new System.Windows.Forms.Button();
            this.BTN_INS = new System.Windows.Forms.Button();
            this.BTN_DEL = new System.Windows.Forms.Button();
            this.BTN_UPD = new System.Windows.Forms.Button();
            this.BTN_next = new System.Windows.Forms.Button();
            this.BTN_last = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(123, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ime";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(123, 194);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(123, 166);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(123, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Email";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(123, 100);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "JMBG";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(123, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Prezime";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(193, 28);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 6;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(193, 228);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 7;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(193, 194);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 8;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(193, 166);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 9;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(193, 135);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 10;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(193, 100);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 20);
            this.textBox6.TabIndex = 11;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(193, 68);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 20);
            this.textBox7.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(123, 228);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "label7";
            // 
            // BTN_first
            // 
            this.BTN_first.Location = new System.Drawing.Point(33, 289);
            this.BTN_first.Name = "BTN_first";
            this.BTN_first.Size = new System.Drawing.Size(58, 23);
            this.BTN_first.TabIndex = 14;
            this.BTN_first.Text = "<<";
            this.BTN_first.UseVisualStyleBackColor = true;
            this.BTN_first.Click += new System.EventHandler(this.BTN_first_Click);
            // 
            // BTN_prev
            // 
            this.BTN_prev.Location = new System.Drawing.Point(106, 289);
            this.BTN_prev.Name = "BTN_prev";
            this.BTN_prev.Size = new System.Drawing.Size(53, 23);
            this.BTN_prev.TabIndex = 15;
            this.BTN_prev.Text = "<";
            this.BTN_prev.UseVisualStyleBackColor = true;
            this.BTN_prev.Click += new System.EventHandler(this.BTN_prev_Click);
            // 
            // BTN_INS
            // 
            this.BTN_INS.Location = new System.Drawing.Point(193, 289);
            this.BTN_INS.Name = "BTN_INS";
            this.BTN_INS.Size = new System.Drawing.Size(75, 23);
            this.BTN_INS.TabIndex = 16;
            this.BTN_INS.Text = "Dodaj";
            this.BTN_INS.UseVisualStyleBackColor = true;
            // 
            // BTN_DEL
            // 
            this.BTN_DEL.Location = new System.Drawing.Point(284, 289);
            this.BTN_DEL.Name = "BTN_DEL";
            this.BTN_DEL.Size = new System.Drawing.Size(75, 23);
            this.BTN_DEL.TabIndex = 17;
            this.BTN_DEL.Text = "Brisi";
            this.BTN_DEL.UseVisualStyleBackColor = true;
            this.BTN_DEL.Click += new System.EventHandler(this.button4_Click);
            // 
            // BTN_UPD
            // 
            this.BTN_UPD.Location = new System.Drawing.Point(377, 289);
            this.BTN_UPD.Name = "BTN_UPD";
            this.BTN_UPD.Size = new System.Drawing.Size(75, 23);
            this.BTN_UPD.TabIndex = 18;
            this.BTN_UPD.Text = "Promeni";
            this.BTN_UPD.UseVisualStyleBackColor = true;
            // 
            // BTN_next
            // 
            this.BTN_next.Location = new System.Drawing.Point(472, 289);
            this.BTN_next.Name = "BTN_next";
            this.BTN_next.Size = new System.Drawing.Size(47, 23);
            this.BTN_next.TabIndex = 19;
            this.BTN_next.Text = ">";
            this.BTN_next.UseVisualStyleBackColor = true;
            this.BTN_next.Click += new System.EventHandler(this.BTN_next_Click);
            // 
            // BTN_last
            // 
            this.BTN_last.Location = new System.Drawing.Point(536, 289);
            this.BTN_last.Name = "BTN_last";
            this.BTN_last.Size = new System.Drawing.Size(46, 23);
            this.BTN_last.TabIndex = 20;
            this.BTN_last.Text = ">>";
            this.BTN_last.UseVisualStyleBackColor = true;
            this.BTN_last.Click += new System.EventHandler(this.BTN_last_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(609, 335);
            this.Controls.Add(this.BTN_last);
            this.Controls.Add(this.BTN_next);
            this.Controls.Add(this.BTN_UPD);
            this.Controls.Add(this.BTN_DEL);
            this.Controls.Add(this.BTN_INS);
            this.Controls.Add(this.BTN_prev);
            this.Controls.Add(this.BTN_first);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button BTN_first;
        private System.Windows.Forms.Button BTN_prev;
        private System.Windows.Forms.Button BTN_INS;
        private System.Windows.Forms.Button BTN_DEL;
        private System.Windows.Forms.Button BTN_UPD;
        private System.Windows.Forms.Button BTN_next;
        private System.Windows.Forms.Button BTN_last;
    }
}

